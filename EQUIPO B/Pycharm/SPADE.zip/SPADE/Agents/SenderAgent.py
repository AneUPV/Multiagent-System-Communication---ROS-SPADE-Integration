""" Authors: Ane López Mena & Maite López Mena """
import time
from spade.agent import Agent
from Behaviours.RequestBehaviour import RequestBehaviour


# ========================================================================== #
#                              ** SENDER AGENT **                            #
# ========================================================================== #
class SenderAgent(Agent):
    # Definir método constructor
    def __init__(self, jid, password, nService, nTarget):
        # Esta clase hereda de la clase Agent, propia de SPADE
        Agent.__init__(self, jid, password)

        # Definir atributos propios del agente Transporte:
        #  1) JID del agente
        self.id = str(jid)
        #  2) Número identificador del servicio
        self.nServ = nService
        #  3) Posición en el almacen
        self.targetPos = nTarget

        # Guardar JID + password, ya que el sender debe comunicarse con
        # los demás agentes y necesita su JID para enviarles mensajes
        self.machine_jid = "machineagent@blah.im"
        self.transport_jid = "transportagent@blah.im"
        self.transport02_jid = "transportagent02@blah.im"
        self.sender_jid = "senderagentacl@blah.im"

        # Es conveniente utilizar este método para introducir la contraseña
        # de forma segura, pero se dejará indicada para la demo

        # passwd = getpass.getpass()
        self.passwd = "upv123"

    # -------------------------------------------------------------
    async def setup(self):
        print("\n[SENDER_AGENT:"+self.sender_jid+"] ")
        print("    |___ Agent setup: Preparing Request Behaviour...")
        print("                    + OK!")

        # Hacer un poco de tiempo de espera para asegurar que el resto de agentes están
        # preparados para recibir peticiones desde SenderAgent
        start = time.time()
        while (time.time() - start < 5):
            pass

        # Instancia el comportamiento RequestBehaviour
        rb = RequestBehaviour(self)

        # Añade el comportamiento al agente
        self.add_behaviour(rb)

        # Si es una solicitud de INTRODUCIR, se avisa primero al TRANSPORTE
        if (self.nServ == 1):
            print("         [Request Behaviour]")
            print("             |___ Sending service request to "+self.transport_jid+"...")
        else:
        # Si es una solicitud de EXTRAER, se avisa primero a la máquina
            print("         [Request Behaviour]")
            print("             |___ Sending service request to "+self.machine_jid+"...")
