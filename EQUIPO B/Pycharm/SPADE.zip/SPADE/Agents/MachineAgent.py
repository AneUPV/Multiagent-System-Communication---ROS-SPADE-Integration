""" Authors: Ane López Mena & Maite López Mena """
from Agents.ResourceAgent import *
from Functionalities.MachineFunctionality import *
from Agents.MFCResourceAgent import MFCResourceAgent

# ========================================================================== #
#                             ** MACHINE AGENT **                            #
# ========================================================================== #
class MachineAgent(MFCResourceAgent):
    # Definir método constructor
    def __init__(self, jid, password):
        ResourceAgent.__init__(self, jid, password)

        # Definir atributos propios del agente Transporte:
        #  1) JID del agente
        self.id = str(jid)

        print("\n[MACHINE_AGENT:" + jid + "]")
        print("    |___ Agent setup: Preparing FSM Behaviour...")
        print("                    + OK!")

        # Definir el listado de tareas de la máquina: MACHINE PLAN
        # Según reciba peticiones, se irán poniendo en cola y ejecutando en orden (FIFO)
        self.machinePlan = []

        # Definir las funcionalidades propias de un recurso MÁQUINA
        self.functionality = MachineFunctionality()
