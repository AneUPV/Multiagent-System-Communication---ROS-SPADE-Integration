""" Authors: Ane López Mena & Maite López Mena """
import time
from opcua import Client
from spade.agent import Agent
from spade.template import Template
from Behaviours.ReceiveBehaviour import ReceiveBehaviour



# ========================================================================== #
#                             ** GW AGENT OPCUA **                           #
# ========================================================================== #
class GWAgentOPCUA(Agent):
    # Definir método constructor
    def __init__(self, jid, password):
        # Esta clase hereda de la clase Agent, propia de SPADE
        Agent.__init__(self, jid, password)
        # Definir atributos propios del agente Transporte:
        #  1) JID del agente
        self.id = str(jid)

        # Instanciar cliente
        self.client = Client("opc.tcp://192.168.0.101:4840")
        # Establecer conexión con servidor OPCUA
        self.client.connect()

        # Llevar máquina a producción normal
        #self.machineSetUp()


# ---------------------------------------------------------------
    async def setup(self):
        print("\n           (!) Starting GWAgentOPCUA... ")
        # Instancia el comportamiento ReceiveBehaviour
        rb = ReceiveBehaviour(self)

        # [PLANTILLAS / TEMPLATES]
        #    | Son necesarias para gestionar la correcta recepción de los mensajes ACL
        # -------
        template = Template()
        template.thread = "READY"
        template.to = "gwagentopcua@blah.im"
        template.sender = "machineagent@blah.im"

        template2 = Template()
        template2.thread = "EXTRACT"
        template2.to = "gwagentopcua@blah.im"
        template2.sender = "machineagent@blah.im"
        # -------

        # Añade el comportamiento al agente y la plantilla para que sepa que "formato" de mensaje espera
        self.add_behaviour(rb, template | template2)
        print("             |___ GWAgentOPCUA running (RecvBehav)\n")

    def machineSetUp(self):

        # Instanciar nodos
        node_AuxInit = self.client.get_node("ns=4;i=9")
        node_Marcha = self.client.get_node("ns=4;i=7")

        # ------- Simular arranque de máquina
        node_AuxInit.set_value(True)
        time.sleep(1)
        node_AuxInit.set_value(False)

        # ------- Simular pulso de "Marcha"
        node_Marcha.set_value(True)
        time.sleep(1)
        node_Marcha.set_value(False)
        time.sleep(2)
