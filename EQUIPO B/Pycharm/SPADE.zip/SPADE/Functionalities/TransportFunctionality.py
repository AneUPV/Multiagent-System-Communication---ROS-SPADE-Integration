""" Authors: Ane López Mena & Maite López Mena """
import time
from spade.message import Message
from RAInterface import RAInterface
from Agents.GWAgentROS import GWAgentROS

# ========================================================================== #
#                      ** TRANSPORT FUNCTIONALITY **                           #
# ========================================================================== #
# Esta clase heredará dos métodos de la interfaz 'RAInterface'
#   1) rcvDataFromAsset
#   2) sendDataToAsset
class TransportFunctionality(RAInterface):
    #   [BOOTING BEHAVIOUR]
    async def init(self):
        # Método de inicialización del agente MÁQUINA
        # Inicializar variables:
        #   1) Flag WIP (WorkInProgress)
        self.WIP = False
        # Estado inicial / predefinido
        self.state = "ACTIVE"

        # Guardar JID + password de GWAgentROS
        gw_jid = "gwagentros@blah.im"
        # No es recomendable dejar la contraseña visible,
        # pero se dejará indicada para la demo
        passwd = "upv123"

        # Instanciar el GWAgentROS para comunicarse con al Asset Físico (AGV).
        ga = GWAgentROS(gw_jid, passwd)
        await ga.start()
        print("           + BOOTING OK!\n")

# ==========================================================================
#   [RUNNING BEHAVIOUR]
    async def execute(self, behav, myAgent):
        # Método de ejecución de las funcionalidades del agente trasnporte. Aquí, el agente se
        # quedará a la escucha de mensajes, y tras recibir una petición, la añadirá al plan de transporte

        print("         + Waiting for signal to start delivery service...\n")

        # A espera de recibir mensajes
        receivedMsg = await behav.receive(timeout=360)

        # Si recibe un mensaje de solicitud de servicio, lo añade al plan de transporte
        if receivedMsg:
            print("         + Message received on TransportAgent(RunningBehaviour) from "+str(receivedMsg.sender))
            print("                 |___ Message received with content: {}".format(receivedMsg.body))

            # Añadir petición al plan de transporte
            myAgent.transportPlan.append(receivedMsg.body)
            print("                 |___ Request added to TransportPlan: " + str(myAgent.transportPlan))
            print("                         + OK!\n")

        else:
            # No ha recibido mensaje en un intervalo de 360 segundos
            print("         + No message received in a while\n")

# ============================================================================================================
#   [NEGOTIATION BEHAVIOUR]
    async def negotiation(self, behav, myAgent):
    # El algoritmo de negociación, tiene 4 fases[0-3]:

    # Variables de control:
        # 1) Paso de la negociación
        step = 0
        # 2) Número de respuestas recibidas
        replyNum = 0

        # Queda a la espera del mensaje CFP ( Call For Proposals)
        CFPMsg = await behav.receive(timeout=360)
        print("\n         (*) MSG RECEIVED IN " + str(myAgent.id) )

        # Extracción de datos del mensaje:
        data = CFPMsg.body.split("#")
        # Lista de recursos transporte disponibles = CANDIDATOS
        contractors = (data[0].split("=")[1])
        targets = contractors.strip('][').split(', ')
        # Negotiation criteria = BATERÍA MÁX.
        criteria = data[1].split("=")[1]

        # Este criterio puede ser diferente según el sistema que se quiera implementar,
        # por tanto, es mejor parametrizarlo
        if (criteria == "battery"):
            myValue = myAgent.battery

        # Si hay más de un transporte disponible (más de 1 candidato)
        if (len(targets)>1):

            # [PASO 0] ________________________________________________________________________
            #   | Se envían mensajes ACL al resto de agentes con los que desea negociar.
            #   | Dichos mensajes incluyen el valor del criterio con el que se desea negociar.

            if (step == 0):
                # Para cada uno de los candidatos
                for jid in targets:
                    # Quitar caracter "'"
                    jid = jid.replace("'", "")

                    # Si no es el JID propio, enviar mensaje
                    if (jid != myAgent.id):
                        print("         -> "+ str(myAgent.id) + " >> " + str(jid).replace("'", "") +": "+ str(myAgent.id) + "," + str(myValue)  )
                        msg2Send = Message(to=str(jid).replace("'", ""), sender=str(myAgent.id), body=str(str(myAgent.id) + "," + str(myValue)))

                        # Settea thread como 'MY_VALUE'
                        msg2Send.thread = "MY_VALUE"

                        # Envía al mensaje al otro transport agent
                        print("             + BATTERY SENT TO "+ str(jid))
                        await behav.send(msg2Send)
                # Pasar a la siguiente etapa
                step = 1

            # [PASO 1] _____________________________________________________________________________
            #   | Se compara el valor propio con los valores recibidos por parte de otros agentes.
            #   | Mientras no se reciban los mensajes de todos los agentes y el valor propio sea mejor
            #   | que los valores recibidos hasta el momento, se permanece a la espera de recibir los
            #   | mensajes con los valores restantes. Si, en algún momento, se detecta que el valor
            #   | propio es peor, se salta al paso 3 y se sale de la negociación. Si, una vez recibidos
            #   | todos los mensajes, el valor propio sigue siendo el mejor, se salta al paso 2.

            if (step == 1):
                # Queda a la espera de mensaje
                replyMsg = await behav.receive(timeout=360)

                if replyMsg:
                    sender_jid = str(replyMsg.body.split(",")[0])
                    sender_value = str(replyMsg.body.split(",")[1])
                    print("\n")
                    print("                 - "+myAgent.id+":    RECEIVED PROPOSAL FROM " + sender_jid + " -> BATTERY: " + sender_value + "%")

                    # Si se detecta que el valor propio es peor, se salta al paso 3
                    if (int(sender_value) > myValue):
                        # Sale de la negociación
                        step = 3
                    replyNum = replyNum + 1
                    print("                 - "+myAgent.id+ ":        No. of proposals received: " + str(replyNum)+"\n")

                    if (replyNum >= len(targets)-1):
                        if (step == 3):
                            step = 3
                        else:
                            # Si, una vez recibidos todos los mensajes, el valor propio sigue siendo el mejor,
                            # se salta al paso 2. Se declara el transport agent como ganador
                            step = 2
            # [PASO 2] _____________________________________________________________________________
            #   | Se informa al agente que solicitó la negociación de que este agente es el ganador
            #   | de la negociación.
            if (step == 2):
                # Se notifica que hay ganador mediante el thread 'WINNER'
                msg2Send = Message(to='machineagent@blah.im', sender=myAgent.id, body=str(myAgent.id))

                # Settea el thread
                msg2Send.thread = "WINNER"

                # Se envía el mensaje
                await behav.send(msg2Send)

                # Se marca el propio agente como ganador
                myAgent.winner = True

            # [PASO 3] _____________________________________________________________________________
            #   | Salir de la negociación cuando se ha perdido.
            if (step == 3):
                myAgent.winner = False
                step = 4
            # [DEFAULT]
            if (step == 4):
                pass

        else:
        # Sólo hay un transporte disponible (por lo tanto, es el único y es el winner)
            print("     =>>>  THE WINNER OF THE NEGOTIATION IS: " + str(myAgent.id) +"("+str(myAgent.battery)+"%)")

            msg2Send = Message(to='machineagent@blah.im', sender=myAgent.id, body=str(myAgent.id))

            # Settea la clave "performative" como "inform"
            msg2Send.thread = "WINNER"

            # Envía al mensaje al resto de candidatos
            await behav.send(msg2Send)
            myAgent.winner = True

# ============================================================================================================
#   [ASSET MANAGEMENT BEHAVIOUR]
    async def rcvDataFromAsset(self, behav, myAgent):
        # Evalúa el valor de un flag de “trabajo en proceso”(WIP) para determinar
        # si un recurso físico está disponible.
        if (self.WIP):

            print("      [*] Transport Agent waiting for message from GWAgentROS... [*]")

            # Espera a que acabe la tarea que está ejecutando
            receivedMsg = await behav.receive(timeout=500)

            # Si el mensaje recibido ha llegado por el thread 'READY'
            if receivedMsg.thread == "READY":

                # Se recoge la tarea finalizada
                task = myAgent.transportPlan[0]
                print("                 |___ Task finished: "+ str(task))

                # Quitar tarea del plan del transporte, puesto que ya se ha realizado con éxito
                myAgent.transportPlan.pop(0)
                print("                 |___ Request removed from TransportPlan: " + str(myAgent.transportPlan))
                print("                         + OK!\n")

                # Obtener tipo de servicio
                taskType = task.split(":")[0]
                # Obtener posición del almacen
                target = task.split(":")[1]

                print("+----------------------------------------------------------------------------+")
                print("| FINISHED SERVICE TYPE: " + str(taskType) + " FOR TARGET: " + str(target) + " |")
                print("+----------------------------------------------------------------------------+")

                # Marca el recurso como no ocupado, es decir, DISPONIBLE
                self.WIP = False

                """ start = time.time()
                # Esperar 5 segundos a que Machine/Transports entren a RUNNING
                while (time.time() - start < 5):
                    pass"""

                # Si la tarea realizada ha sido de tipo 'INTRODUCE'
                if (taskType == "INTRODUCE"):
                    # Enviar otra solicitud de servicio a MACHINE AGENT
                    print("         + Sending task: TRANSPORT AGENT >>> MACHINE AGENT")
                    # Generar el mensaje para enviar
                    msg2Send = Message(to="machineagent@blah.im", sender=myAgent.id, body=str(task))
                    # Settear el thread como 'READY'
                    msg2Send.thread = "READY"
                    # Envía al mensaje
                    await behav.send(msg2Send)

                    return "OK"
                # Si la tarea es de tipo 'EXTRACT', termina aquí
                else:
                    return None
            else:
                # Si el mensaje recibido no viene por el thread correcto, ignorarlo
                print("")

# ----------------------------------------------------------------------------------------------------
    async def sendDataToAsset(self, behav, myAgent):
        # Evalúa el valor de un flag de “trabajo en proceso”(WIP) para determinar
        # si un recurso físico está disponible. Si es así, también comprueba las peticiones de
        # servicio pendientes relacionadas con el recurso (plan de transporte).
        # Si se dan esas condiciones, la información relativa a la siguiente petición de servicio
        # se envía al gateway (pasarela). Una vez se haya envíado la información, el flag “trabajo
        # en proceso” se activa para bloquear el envío de nueva información, hasta que el servicio actual
        # se haya completado (WIP=True).

        # Procesar las tareas del plan de transporte
        if (not self.WIP and len(myAgent.transportPlan) > 0):


            # Obtener tarea
            task = myAgent.transportPlan[0]
            # Obtener tipo de servicio a realizar
            taskType = task.split(":")[0]
            print("         + Sending task: "+ str(myAgent.id) +" >>> GW AGENT ROS")

            # Instancia el mensaje a enviar:
            msg2Send = Message(to="gwagentros@blah.im", sender=myAgent.id, body=str(taskType))
            msg2Send.thread = str(taskType)

            # Envía al mensaje al GWAgentROS
            await behav.send(msg2Send)

            # Marcar el transporte como OCUPADO
            self.WIP = True

            print("                 |___ Request sent to GatewayAgentROS: ['" + str(task) + "']")
            print("                         + OK!\n")

            return "OK"

        # Si la lista de tareas está vacía o transport está ocupado
        else:
            return None

# ============================================================================================================
#   [STOPPING BEHAVIOUR]
    def stop(self):
        print("Stopping TransportAgent...")
        print("            + OK!\n")

# ============================================================================================================
#   [IDLE BEHAVIOUR]
    def idle(self):
        print("Transport status: IDLE")
