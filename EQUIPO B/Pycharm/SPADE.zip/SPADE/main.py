""" Authors: Ane López Mena & Maite López Mena """
import time
import spade
from Agents.MachineAgent import MachineAgent
from Agents.TransportAgent import TransportAgent
from Agents.SenderAgent import SenderAgent

async def main():

    print("+------------------------------------------------------------+")
    print("|            MULTIAGENT SYSTEM COMMUNICATION -               |")
    print("|             ** Maite López y Ane López **                  |")
    print("|             =============================                  |")
    print("|                - Trabajo Fin de Grado -                    |")
    print("|                     - 2023-2024 -                          |")
    print("+------------------------------------------------------------+\n")


    # Guardar JID + PASSWORD de los agentes creados
    machine_jid = "machineagent@blah.im"
    transport_jid = "transportagent@blah.im"
    transport02_jid = "transportagent02@blah.im"
    sender_jid = "senderagentacl@blah.im"

    # Es conveniente utilizar este método para introducir la contraseña
    # de forma segura, pero se dejará indicada para la demo

    # passwd = getpass.getpass()
    passwd = "upv123"

#=====================================================================================

# El objetivo del presente programa es demostrar la comunicación de las diferentes máquinas
# de un entorno de producción, empleando para ello la plataforma SPADE.
# SPADE está dirigida al desarrollo de agentes en el lenguaje de programación Python.

# Los recursos involucrados son los listados a continuación:
#  1) Recurso máquina: Automated Warehouse
#  2) Recurso transporte: Robot AGV - Turtlebot3 (Modelo 'Burger')
#
# El sistema implementado consiste en un almacén automático, en el que los usuarios
# podrán solicitar 2 servicios diferentes:
#   |
#   |----> INTRODUCIR (Servicio 1) - El usuario indicará una posición (targetPosition)
#   |                                donde almacenar el material. Ese material será suministrado
#   |                                por un robot de navegación autónoma (AGV).
#   |
#   |----> EXTRAER    (Servicio 2) - El usuario indicará una posición (targetPosition) del
#                                    almacén para extraer material. Una vez extraído, la máquina,
#                                    se comunicará con los transportes para realizar el reparto del material.

# ===========================================================================================

    # Indicar el número máximo de servicios
    maxServices = 2

    # Pedir por consola el servicio a realizar
    nServ = int(input("|----> Choose SERVICE TYPE:  * INTRODUCE (1) * EXTRACT (2) : "))
    print("            + SERVICE TYPE: " + str(nServ))

    # Si la entrada no ha sido correcta, volverá a preguntar
    while not 0 < nServ < (maxServices + 1):
        print("                  ** ERROR **\n     /!\ Service type is not valid [1-" + str(maxServices) + "] /!\ ")
        nServ = int(input("                 |----> Choose SERVICE TYPE:  * INTRODUCE (1) * EXTRACT (2): "))
        print("            + SERVICE TYPE: " + str(nServ))

    # Pedir la posición del almacén para almacenar/extraer material
    targetPos = int(input("|----> Choose TARGET POSITION (1-54):"))
    print("            + SHELF No.: " + str(targetPos))

    # Si la entrada no ha sido correcta, volverá a preguntar
    while not 0 < targetPos < 55:
        print("                  ** ERROR **\n     /!\  TARGET POSITION is not valid [1-54]  /!\ ")
        targetPos = int(input("                 |----> Choose TARGET POSITION (1-54):"))
        print("                             + SHELF No.: " + str(targetPos))

#===========================================================================================

    start = time.time()

    print(" _______________________________________________________________________________")
    print('·::::::::::::::::::[ INITIALIZATING ENVIRONMENT AND ASSETS ]:::::::::::::::::::·')

    if (nServ == 1):

        # Si se solicita el servicio 'INTRODUCE', se instancian:
        #   * 1 MAQUINA
        #   * 1 TRANSPORTE

        # Inicialización de agente transporte 01
        ta = TransportAgent(transport_jid, passwd)
        await ta.start()


        # Inicialización de agente máquina
        ma = MachineAgent(machine_jid, passwd)
        await ma.start()

        # Esperar 5 segundos a que Machine y Transport entren en estado RUNNING
        while (time.time() - start < 5):
            pass;pass



        # Inicialización de agente Sender, para notificar al transporte de la petición de servicio
        sa = SenderAgent(sender_jid, passwd, nServ, targetPos)
        await sa.start()

        # Dejar código a la espera hasta finalización de agentes
        await spade.wait_until_finished(ma)
        await spade.wait_until_finished(ta)

    else:
        # SI se solicita el servicio 'EXTRACT', se instancian:
        #   * 1 MAQUINA
        #   * 2 TRANSPORTES

        # Inicialización de agente máquina
        ma = MachineAgent(machine_jid, passwd)
        await ma.start()

        # Inicialización de agente transporte 01
        ta = TransportAgent(transport_jid, passwd)
        await ta.start()

        # Inicialización de agente transporte 02
        ta2 = TransportAgent(transport02_jid, passwd)
        await ta2.start()

        # Inicialización de agente Sender, para notificar a la máquina de la petición de servicio
        sa = SenderAgent(sender_jid, passwd, nServ, targetPos)
        await sa.start()

        # Dejar código a la espera hasta finalización de agentes
        await spade.wait_until_finished(ma)
        await spade.wait_until_finished(ta)
        await spade.wait_until_finished(ta2)

    print(" -- Agents finished --")

# ====================================================================
# Programa principal 'MAIN', desde el que se iniciará el entorno
if __name__ == "__main__":
    spade.run(main())
    start = time.time()
