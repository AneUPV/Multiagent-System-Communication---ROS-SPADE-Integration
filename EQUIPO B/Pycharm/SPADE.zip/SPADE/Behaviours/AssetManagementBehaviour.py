""" Authors: Ane López Mena & Maite López Mena """
from spade.behaviour import CyclicBehaviour

# ========================================================================== #
#                      ** ASSET MANAGEMENT BEHAVIOUR **                      #
# ========================================================================== #
# Define el comportamiento del Agente como "CyclicBehaviour"
class AssetManagementBehaviour(CyclicBehaviour):
    # Definir método constructor
    def __init__(self, a):
        # Heredamos el init de la clase super
        super().__init__()

        # Definir atributos propios del agente:
        #  1) Instancia del agente que ejecuta el comportamiento
        self.myAgent = a

    #----------------------------------------------
    async def run(self):
        msg = await self.myAgent.functionality.sendDataToAsset(self, self.myAgent)

        # Si el método 'SendDataToAsset' recibe un mensaje, llamamos al método 'rcvDataFromAsset'
        if (msg == "OK"):
            await self.myAgent.functionality.rcvDataFromAsset(self, self.myAgent)
