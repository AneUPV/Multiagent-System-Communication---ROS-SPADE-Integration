""" Authors: Ane López Mena & Maite López Mena """
from spade.message import Message
from spade.behaviour import OneShotBehaviour

# ========================================================================== #
#                           ** REQUEST BEHAVIOUR **                          #
# ========================================================================== #
# Define el comportamiento del Agente como "OneShotBehaviour"
class RequestBehaviour(OneShotBehaviour):
    # Definir método constructor
    def __init__(self, a):
        # Heredamos el init de la clase super
        super().__init__()
        # Definir atributos propios del agente:
        #  1) Instancia del agente que ejecuta el comportamiento
        self.myAgent = a

    # ------------------------------------------------------------------

    async def run(self):
        # Servicio 1: INTRODUCE
       if (self.myAgent.nServ == 1):

           # 1) Envía mensaje de solicitud a TransportAgent ----------------------
           # Define el mensaje : TO, SENDER Y THREAD
           msg2Send = Message(to=str(self.myAgent.transport_jid), sender=self.myAgent.id, body="INTRODUCE:"+str(self.myAgent.targetPos))
           msg2Send.thread = "INTRODUCE"

           # Envía al mensaje a TransportAgent
           await self.send(msg2Send)
           print("         + Message sent to " + self.myAgent.transport_jid + " from " + self.myAgent.id + " (RcvBehaviour)")

       else:
           # Servicio 2: EXTRACT

           # 1) Envía mensaje de solicitud a MachineAgent ----------------------

           # Define el mensaje : TO, SENDER Y THREAD
           msg2Send = Message(to=self.myAgent.machine_jid, sender=self.myAgent.id,body="EXTRACT:" + str(self.myAgent.targetPos))
           msg2Send.thread = "EXTRACT"

           # Envía al mensaje a MachineAgent
           await self.send(msg2Send)
           print("         + Message sent to " + self.myAgent.machine_jid, + " from " + self.myAgent.id + " (RcvBehaviour)")


