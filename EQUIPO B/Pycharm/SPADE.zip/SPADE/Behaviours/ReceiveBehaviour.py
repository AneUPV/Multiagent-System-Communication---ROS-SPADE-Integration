""" Authors: Ane López Mena & Maite López Mena """
import time
import logging
import opcua.ua
from opcua import Client
from spade.message import Message
from spade.template import Template
from spade.behaviour import CyclicBehaviour

# ========================================================================== #
#                          ** RECEIVE BEHAVIOUR **                           #
# ========================================================================== #
# Define el comportamiento del Agente como "CyclicBehaviour"
class ReceiveBehaviour(CyclicBehaviour):
    # Definir método constructor
    def __init__(self, a):
        # Heredamos el init de la clase super
        super().__init__()
        # Definir atributos propios del agente:
        #  1) Instancia del agente que ejecuta el comportamiento
        self.myAgent = a

    # ------------------------------------------------------------------
    async def run(self):
        # Queda a la espera de recibir un mensaje
        msg = await self.receive()

        # Si recibe un mensaje:
        if msg:
            # Se configura la información de logging: Imprime líneas con información sobre la conexión
            logging.basicConfig(level=logging.INFO)
            print("         + Message received on GWAgent: GW AGENT (RcvBehaviour)")
            print("                 |___ Message received with content: {}".format(msg.body))

            # Se extraen del mensaje recibido el tipo de servicio y la posición
            taskType = str(msg.body).split(":")[0]
            target = str(msg.body).split(":")[1]

            # Si el tipo de servicio es 'INTRODUCE'
            if taskType == "INTRODUCE":
                print("     [!] Introducing package into shelf No.  " +str(target ) +" [!]")
                print("               + Sending data to OPC UA Server...")

                result = await self.sendDataOPCUA(taskType, target)

                if (result == "FINISHED"):
                    print("+-----------------------------------------------------+")
                    print("| Package SUCCESSFULLY STORED in AUTOMATED WAREHOUSE  |")
                    print("|     |____Establishing communication with [MACHINE AGENT]:machineagent@blah.im")

                    # Crear un Template para responder al agente transporte
                    template2 = Template()
                    template2.sender = "gwagentopcua@blah.im"
                    template2.to = "transportagent@blah.im"

                    # Mensaje para actualizar plan de máquina
                    msg2Send = Message(to=str(msg.sender), sender=str(self.myAgent.id))
                    msg2Send.thread = "DONE"

                    # Envía al mensaje al GWAgent
                    await self.send(msg2Send)
                    await self.send(msg2Send)
                    await self.send(msg2Send)

                else:
                    print("+-----------------** ERROR **-------------------+")
                    print("| Shelf No. "+ str(target)+" already OCCUPIED!! |")
                    print("+-----------------------------------------------+")
            else:
                # Si el tipo de servicio es 'EXTRACT'
                print("     [!] Extracting box from shelf No. " + str(target) +" [!]")
                print("               + Sending data to OPC UA Server...")

                result = await self.sendDataOPCUA(taskType, target)

                print("+---------------------------------------------------------+")
                print("| Package SUCCESSFULLY EXTRACTED from AUTOMATED WAREHOUSE |")
                print("|   |____Establishing communication with [MACHINE AGENT]:machineagent@blah.im")


                if (result == "FINISHED"):

                    # Mensaje para actualizar plan de máquina
                    msg2Send = Message(to=str(msg.sender), sender=str(self.myAgent.id))
                    msg2Send.thread = "DELIVERY"
                    # Envía al mensaje al GWAgent
                    await self.send(msg2Send)

                else:
                    print("\n+-----------------** ERROR **-------------------+")
                    print("|             Shelf No. " + str(target) + " is EMPTY!!            |")
                    print("+-----------------------------------------------+")

# ====================================================================

    async def sendDataOPCUA(self, nServ, targetPos):
    # En este método se realiza toda la lógica de lectura/escritura de nodos
    # publicados en la interfaz del servidor OPC UA
        # --------------------------------------------------------------------------------
        # Instanciar cliente
        self.myAgent.client = Client("opc.tcp://192.168.0.101:4840")
        # Establecer conexión con servidor OPCUA
        self.myAgent.client.connect()

        # Obtener el servicio y la posición a procesar
        target = int(targetPos)
        serviceType = nServ


        # Instanciar nodos con los que se realizarán las operaciones rw
        node_Reset = self.myAgent.client.get_node("ns=4;i=8")
        node_CogerDejar = self.myAgent.client.get_node("ns=4;i=10")
        node_Posicion = self.myAgent.client.get_node("ns=4;i=66")
        node_ServiceFinished = self.myAgent.client.get_node("ns=4;i=5")
        node_AlmacenOcupacion = self.myAgent.client.get_node("ns=4;i=11")

        # --------- Prod. Normal ------------
        # Escribir tipo de servicio solicitado
        #     * INTRODUCIR ( CogerDejar = 1 )
        if (serviceType == 'INTRODUCE'):
            node_CogerDejar.set_value(True)
        else:
        #   * EXTRAER ( CogerDejar = 0 )
            node_CogerDejar.set_value(False)

        # Escribir posición objetivo de la solicitud
        node_Posicion.set_value(target, varianttype=opcua.ua.VariantType.Int16)

        # Comprobar si la acción es realizable
        ok = self.servicePossible(node_AlmacenOcupacion, serviceType, target)

        # Si no existen impedimentos para la puesta en marcha
        if (ok):
            # Simular pulso de Reset
            node_Reset.set_value(True)
            time.sleep(1)
            node_Reset.set_value(False)

            # Crear una variable que notifica del estado del proceso.
            # Cuando haya terminado la tarea, se pondrá en True
            finished = False

            while not finished:
                finished = node_ServiceFinished.get_value()

            print("          + SERVICE FINISHED!")

            # Devolver señal de tarea FINALIZADA
            return "FINISHED"
        else:
            # Si no existen impedimentos para la puesta en marcha
            # Simular pulso de Reset
            node_Reset.set_value(True)
            time.sleep(1)
            node_Reset.set_value(False)

            # Devolver señal de ERROR
            return "ERROR"

#=========================================================================
    def servicePossible(self, node_AlmacenOcupacion, service, target):
    # Este método permite saber si la operación solicitada puede realizarse
    # o si existe algún problema que no permita su puesta en marcha.


        # Obtener matriz de ocupación del almacén
        warehouseOcupation = node_AlmacenOcupacion.get_value()

        # Si se quiere INTRODUCIR Y la posición está ocupada
        if (service == 'INTRODUCE' and warehouseOcupation[target - 1] == True):
            return False
        # Si se quiere EXTRAER Y la posición está vacía
        if (service == 'EXTRACT' and warehouseOcupation[target - 1] == False):
            return False
        return True
